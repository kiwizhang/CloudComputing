import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import io.undertow.Undertow;
import io.undertow.server.*;
import io.undertow.util.Headers;

/**
 * The class for undertwo framework
 * 
 */
public class HBaseQuery {
//	private final static int CACHE_SIZE = 4500000;
//    /**
//    *  LinkedHashMap for LRU Cache
//    */
//    private static LinkedHashMap<String, String> cache = new LinkedHashMap<String, String>(CACHE_SIZE, .75F, true) {
//        /**
//         * 
//         */
//        private static final long serialVersionUID = 1L;
//        protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
//            return size() > CACHE_SIZE;
//        }
//    };
//    
    /**
     *  The method to retrieve tweets from HBase
     *  The return value will be the response to the client
     */
    private static String retrieveTweets(String startId, String stopId, String startDate, String stopDate, String[] wordList) {
        String info = null;
        System.out.println("retrieve tweets");

//        if (cache.containsKey(userid + "&" + hashtag)) {
//            info = cache.get(userid + "&" + hashtag);
//        } else {
        	String result;
			try {
                System.out.println("get tweet");

				result = HBaseTasks.getTweet(startId, stopId, startDate, stopDate, wordList);
				
	            info = String.format("ThreeKings,9675-1473-0896\n%s", result);
//		    cache.put(userid + "&" + hashtag, info);
			} catch (IOException e) {
				e.printStackTrace();
			}      
//        }
        return info;
    }
    
    public static void main(final String[] args) {
        System.out.println("before start server");

        Undertow server = Undertow.builder().addHttpListener(8080, "ec2-54-172-78-110.compute-1.amazonaws.com")
                .setHandler(new HttpHandler() {

                    public void handleRequest(final HttpServerExchange exchange) throws Exception {
                        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "text/plain;charset=utf-8");
                        try {
                            System.out.println("handle request");

                            String startId = exchange.getQueryParameters().get("start_userid").getFirst();
                            String stopId = exchange.getQueryParameters().get("end_userid").getFirst();
                            String startDate = exchange.getQueryParameters().get("start_date").getFirst();
                            String stopDate = exchange.getQueryParameters().get("end_date").getFirst();
                            String words = exchange.getQueryParameters().get("word").getFirst();
                            String[] wordList = words.split(",");
                            System.out.println("startId: " + startId + "stopId: " + stopId + "start_date: " + startDate + "stop_date: " + stopDate);
                            for (String word: wordList) {
                            	System.out.println(word);
                            }

                            String info = retrieveTweets(startId, stopId, startDate, stopDate, wordList);
                            exchange.getResponseSender().send(info);
                        } catch (Exception e) {
                            exchange.getResponseSender().send("this is an error page.");
                        }
                    }
                }).build();
        server.start();
    }
}
