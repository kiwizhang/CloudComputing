import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.client.coprocessor.AggregationClient;
import org.apache.hadoop.hbase.client.coprocessor.BigDecimalColumnInterpreter;
import org.apache.hadoop.hbase.coprocessor.ColumnInterpreter;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The class for data query in HBase
 * 
 */

public class HBaseTasks {

    /**
     * The private IP address of HBase master node.
     */
    private static String zkAddr = "54.172.78.110";
    /**
     * The name of your HBase table.
     */
    private static String tableName = "finaldata";
    
    private static final byte[] TEST_TABLE = Bytes.toBytes(tableName); 

    /**
     * HTable handler.
     */
    private static HTableInterface tweetsTable;
    /**
     * HBase connection.
     */
    private static HConnection conn;
    /**
     * Byte representation of column family.
     */
    private static byte[] bColFamily = Bytes.toBytes("data");
    /**
     * Logger.
     */
    private final static Logger logger = Logger.getRootLogger();
    private final static Configuration conf = HBaseConfiguration.create();



    /**
     * Initialize HBase connection.
     * @throws IOException
     */
    private static void initializeConnection() throws IOException {
        // Remember to set correct log level to avoid unnecessary output.
        logger.setLevel(Level.ERROR);
        conf.set("hbase.master", zkAddr + ":60000");
        conf.set("hbase.zookeeper.quorum", zkAddr);
        conf.set("hbase.zookeeper.property.clientport", "2181");
	    if (!zkAddr.matches("\\d+.\\d+.\\d+.\\d+")) {
		    System.out.print("HBase not configured!");
		    return;
	    }
        conn = HConnectionManager.createConnection(conf);
        tweetsTable = conn.getTable(Bytes.toBytes(tableName));
    }

    /**
     * Clean up resources.
     * @throws IOException
     */
    private static void cleanup() throws IOException {
        if (tweetsTable != null) {
            tweetsTable.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    /**
     * the method to get data from Hbase. 
     */

    public static String getTweet(String startId, String stopId, String startDate, String stopDate, String[] wordList) throws IOException {
    	
    	if (tweetsTable == null || conn == null) {
    		initializeConnection();
        }
        return query(startId, stopId, startDate, stopDate, wordList);
    }
    /**
     * This is a method to use "get" operation to query from HBase
     * It pass in the key and return the value from HBase
     * @throws IOException
     */
    
    private static String query(String startId, String stopId, String startDate, String stopDate, String[] wordList) throws IOException {
//    	  AggregationClient aClient = new AggregationClient(conf);
    	Map<String, Integer> wordmap = new HashMap<String, Integer>();
    	wordmap.put(wordList[0], 0);
    	wordmap.put(wordList[1], 0);
    	wordmap.put(wordList[2], 0);
    	String minWord = wordList[0];
    	String maxWord = minWord;
    	for (String word: wordList) {
    		if (word.compareTo(minWord) < 0) {
    			minWord = word;
    		} else if (word.compareTo(minWord) > 0) {
    			maxWord = word;
    		}
    	}
        System.out.println("minword: " + minWord + "maxword: " + maxWord);

    	String startRowString = startId + startDate + minWord;
    	String stopRowString = stopId + stopDate + maxWord;
    	byte[] startRow = Bytes.toBytes(startRowString);
    	byte[] stopRow = Bytes.toBytes(stopRowString);
    	Scan scan = new Scan();
    	

    	scan.setStartRow(startRow);
    	scan.setStopRow(stopRow);  
    	
        System.out.println("finish setting start and stop row");

        byte[] bCol1 = Bytes.toBytes("userid");
        byte[] bCol2 = Bytes.toBytes("date");
        byte[] bCol3 = Bytes.toBytes("word");
        byte[] bCol4 = Bytes.toBytes("count");
        
        System.out.println("finish setting bCol");


        scan.addColumn(bColFamily, bCol1);
        scan.addColumn(bColFamily, bCol2);
        scan.addColumn(bColFamily, bCol3);
        scan.addColumn(bColFamily, bCol4);
        
        System.out.println("finish adding column");

        
    	BinaryComparator comp11 = new BinaryComparator(Bytes.toBytes(startId)); 
    	BinaryComparator comp12 = new BinaryComparator(Bytes.toBytes(stopId)); 
    	BinaryComparator comp21 = new BinaryComparator(Bytes.toBytes(startDate)); 
    	BinaryComparator comp22 = new BinaryComparator(Bytes.toBytes(stopDate)); 
    	RegexStringComparator comp31 = new RegexStringComparator(wordList[0]);
    	RegexStringComparator comp32 = new RegexStringComparator(wordList[1]);
    	RegexStringComparator comp33 = new RegexStringComparator(wordList[2]);
    	
        System.out.println("finish creating comparator column");


        List<Filter> listOfFilter = new ArrayList<Filter>();
        //Filter ID
        Filter filter11 = new SingleColumnValueFilter(bColFamily, bCol1, CompareFilter.CompareOp.GREATER_OR_EQUAL, comp11);
        Filter filter12 = new SingleColumnValueFilter(bColFamily, bCol1, CompareFilter.CompareOp.LESS_OR_EQUAL, comp12);
        //Filter date
        Filter filter21 = new SingleColumnValueFilter(bColFamily, bCol2, CompareFilter.CompareOp.GREATER_OR_EQUAL, comp21);
        Filter filter22 = new SingleColumnValueFilter(bColFamily, bCol2, CompareFilter.CompareOp.LESS_OR_EQUAL, comp22);
        Filter filter31 = new SingleColumnValueFilter(bColFamily, bCol3, CompareFilter.CompareOp.EQUAL, comp31);
        Filter filter32 = new SingleColumnValueFilter(bColFamily, bCol3, CompareFilter.CompareOp.EQUAL, comp32);
        Filter filter33 = new SingleColumnValueFilter(bColFamily, bCol3, CompareFilter.CompareOp.EQUAL, comp33);

        
        listOfFilter.add(filter11);
        listOfFilter.add(filter12);
        listOfFilter.add(filter21);
        listOfFilter.add(filter22);
        listOfFilter.add(filter31);
        listOfFilter.add(filter32);
        listOfFilter.add(filter33);
        
        System.out.println("finish adding filter");


        FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL, listOfFilter);
        scan.setFilter(filterList);
        
        System.out.println("finish adding filterList");

        
//        final ColumnInterpreter<BigDecimal, BigDecimal> ci = new BigDecimalColumnInterpreter();
       
//        BigDecimal sum = aClient.sum(TEST_TABLE, ci, scan);
        ResultScanner rs = tweetsTable.getScanner(scan);
        for (Result r = rs.next(); r != null; r = rs.next()) {
        	System.out.println("looping word: " + r.getValue(bColFamily, bCol3) + "count: " + Bytes.toInt(r.getValue(bColFamily, bCol4)));
            if(Bytes.toString(r.getValue(bColFamily, bCol3)).equals(wordList[0])) {
            	wordmap.put(wordList[0], wordmap.get(wordList[0]) + Bytes.toInt(r.getValue(bColFamily, bCol4)));
            } else if (Bytes.toString(r.getValue(bColFamily, bCol3)).equals(wordList[1])) {
            	wordmap.put(wordList[1], wordmap.get(wordList[1]) + Bytes.toInt(r.getValue(bColFamily, bCol4)));
            } else if (Bytes.toString(r.getValue(bColFamily, bCol3)).equals(wordList[2])) {
            	wordmap.put(wordList[2], wordmap.get(wordList[2]) + Bytes.toInt(r.getValue(bColFamily, bCol4)));
            } else {
            	continue;
            }
        }
        System.out.println("finish rs");

        StringBuilder sb = new StringBuilder();
        sb.append(wordList[0] + ":" + wordmap.get(wordList[0]) + "\n").append(wordList[1] + ":" + wordmap.get(wordList[1]) + "\n").append(wordList[2] + ":" + wordmap.get(wordList[2]) + "\n");
        rs.close();
        return sb.toString();
    }
    

   
    

}
